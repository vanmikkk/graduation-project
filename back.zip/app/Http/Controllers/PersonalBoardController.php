<?php

namespace App\Http\Controllers;

use App\Models\Token;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Board;
use App\Models\Column;
use App\Models\Card;

class PersonalBoardController extends Controller
{
    private function getUserIdFromToken(Request $request)
    {
        $token = $request->bearerToken();
        if (!$token) return null;
        
        $tokenRecord = Token::where("token", $token)->first();
        return $tokenRecord ? $tokenRecord->user_id : null;
    }

    /**
     * Получить всю доску пользователя со всеми колонками и карточками
     */
    public function index(Request $request)
    {
        $userId = $this->getUserIdFromToken($request);
        if (!$userId) return response()->json(['message' => 'Unauthorized'], 401);

        // 1. Находим доску пользователя
        // Предполагаем, что у каждого юзера одна личная доска. 
        // Если их может быть несколько, нужно передавать board_id в запросе.
        $board = Board::where('user_id', $userId)->first();

        if (!$board) {
            // Если доски нет, создадим дефолтную
            $board = Board::create([
                'user_id' => $userId,
                'config' => json_encode(['theme' => 'default']) // Пример конфига
            ]);
        }

        // 2. Получаем все колонки этой доски, отсортированные по sort
        $columns = Column::where('board_id', $board->id)
            ->orderBy('sort')
            ->get()
            ->map(function ($column) use ($userId) {
                // 3. Для каждой колонки получаем карточки
                // Карточки могут быть привязаны к колонке И к пользователю (если это общая доска курса)
                // Но для личной доски достаточно column_id
                $cards = Card::where('column_id', $column->id)
                    // ->where('user_id', $userId) // Раскомментируй, если cards имеют user_id и нужно фильтровать
                    ->orderBy('sort')
                    ->get();

                return [
                    'id' => $column->id,
                    'name' => $column->name,
                    'sort' => $column->sort,
                    'cards' => $cards
                ];
            });

        return response()->json([
            'board_id' => $board->id,
            'columns' => $columns
        ]);
    }

    /**
     * Создать новую карточку
     */
    public function storeCard(Request $request)
    {
        $userId = $this->getUserIdFromToken($request);
        if (!$userId) return response()->json(['message' => 'Unauthorized'], 401);

        $validated = $request->validate([
            'column_id' => 'required|exists:columns,id',
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'date' => 'nullable|date', // Твое поле date в таблице cards
        ]);

        // Проверка прав: принадлежит ли колонка доске пользователя?
        $column = Column::findOrFail($validated['column_id']);
        $board = Board::findOrFail($column->board_id);
        
        if ($board->user_id !== $userId) {
            return response()->json(['message' => 'Access denied'], 403);
        }

        // Вычисляем следующий порядок сортировки
        $maxSort = Card::where('column_id', $column->id)->max('sort');

        $card = Card::create([
            'user_id' => $userId,
            'column_id' => $column->id,
            'name' => $validated['name'],
            'description' => $validated['description'] ?? null,
            'date' => $validated['date'] ?? null,
            'sort' => ($maxSort ?? 0) + 1,
        ]);

        return response()->json($card, 201);
    }

    /**
     * Обновить карточку или порядок колонок/карточек (Drag-and-Drop)
     */
    public function update(Request $request)
    {
        $userId = $this->getUserIdFromToken($request);
        if (!$userId) return response()->json(['message' => 'Unauthorized'], 401);

        // Ожидаем структуру для массового обновления порядка:
        // { type: 'cards', items: [{id, column_id, sort}, ...] }
        // ИЛИ { type: 'columns', items: [{id, sort}, ...] }
        
        $data = $request->all();
        
        if (!isset($data['type']) || !isset($data['items'])) {
            return response()->json(['message' => 'Invalid data format'], 422);
        }

        DB::transaction(function () use ($data, $userId) {
            foreach ($data['items'] as $item) {
                if ($data['type'] === 'cards') {
                    // Обновление позиции карточки
                    $card = Card::where('id', $item['id'])->first();
                    if ($card && $card->user_id == $userId) {
                        $card->update([
                            'column_id' => $item['column_id'],
                            'sort' => $item['sort']
                        ]);
                    }
                } elseif ($data['type'] === 'columns') {
                    // Обновление позиции колонки
                    // Нужно проверить, что колонка принадлежит доске пользователя
                    $column = Column::join('boards', 'columns.board_id', '=', 'boards.id')
                        ->where('columns.id', $item['id'])
                        ->where('boards.user_id', $userId)
                        ->select('columns.*')
                        ->first();
                    
                    if ($column) {
                        $column->update(['sort' => $item['sort']]);
                    }
                }
            }
        });

        return response()->json(['message' => 'Updated successfully']);
    }

    /**
     * Удалить карточку
     */
    public function destroyCard(Request $request, $id)
    {
        $userId = $this->getUserIdFromToken($request);
        if (!$userId) return response()->json(['message' => 'Unauthorized'], 401);

        $card = Card::where('id', $id)->where('user_id', $userId)->first();
        if (!$card) return response()->json(['message' => 'Card not found'], 404);

        $card->delete();
        return response()->json(['message' => 'Deleted']);
    }
    
    /**
     * Обновить данные карточки (редактирование)
     */
    public function updateCard(Request $request, $id)
    {
        $userId = $this->getUserIdFromToken($request);
        if (!$userId) return response()->json(['message' => 'Unauthorized'], 401);

        // Ищем карточку и проверяем, что она принадлежит пользователю
        $card = Card::where('id', $id)
                    ->where('user_id', $userId)
                    ->first();

        if (!$card) {
            return response()->json(['message' => 'Карточка не найдена'], 404);
        }

        $validated = $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
            'date' => 'nullable|date',
        ]);

        // Обновляем только переданные поля
        $card->update($validated);

        return response()->json($card);
    }
    
    
    /**
     * Создать новую колонку
     */
    public function storeColumn(Request $request)
    {
        $userId = $this->getUserIdFromToken($request);
        if (!$userId) return response()->json(['message' => 'Unauthorized'], 401);

        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'board_id' => 'required|exists:boards,id',
        ]);

        // Проверка прав: принадлежит ли доска пользователю?
        $board = Board::where('id', $validated['board_id'])
                      ->where('user_id', $userId)
                      ->firstOrFail();

        // Вычисляем следующий порядок сортировки
        $maxSort = Column::where('board_id', $board->id)->max('sort');

        $column = Column::create([
            'board_id' => $board->id,
            'name' => $validated['name'],
            'sort' => (int)($maxSort ?? 0) + 1,
        ]);

        return response()->json($column, 201);
    }
}