<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\User_in_course;
use App\Models\Token;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function index()
    {
        $courses = Course::all();

        return response()->json($courses, 200);
    }

    public function indexId(Request $request)
    {
        $token = $request->bearerToken();
        $user_id = Token::where("token", $token)->first()->user_id;
        $course_id = $request->input("course_id");

        $course = User_in_course::where("user_id", $user_id)->where("course_id", $course_id)->first();
        $ownerCourse = Course::where("user_id", $user_id)->where("id", $course_id)->first();

        if($course == null && $ownerCourse == null){
            return response()->json("У вас нет доступа к этому курсу", 422);
        }

        $course = Course::where("id", $request->input("course_id"))->first();

        return response()->json($course, 200);
    }

    public function indexByUserOwner(Request $request)
    {
        $user_id = Token::where("token", $request->bearerToken())->first()->user_id;
        $course = Course::where("user_id", $user_id)->latest()->get();

        return response()->json($course, 200);
    }

    public function create(Request $request)
    {
        $name = $request->input("name");
        $token = $request->bearerToken();
        $user_id = Token::where("token", $token)->first()->user_id;

        $randomNumber = rand(1, 4);

        $course = Course::create([
            "name" => $name,
            "access_code" => $this->generateSecureCode(6),
            "user_id" => $user_id,
            "img_id" => $randomNumber,
        ]);

        return response()->json($course, 200);
    }

    private function generateSecureCode($length = 6)
    {
        $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $lowercase = 'abcdefghijklmnopqrstuvwxyz';
        $numbers = '0123456789';

        $code = '';
        $code .= $uppercase[random_int(0, strlen($uppercase) - 1)];
        $code .= $lowercase[random_int(0, strlen($lowercase) - 1)];
        $code .= $numbers[random_int(0, strlen($numbers) - 1)];

        $allChars = $uppercase . $lowercase . $numbers;
        $remainingLength = $length - 3;

        for ($i = 0; $i < $remainingLength; $i++) {
            $code .= $allChars[random_int(0, strlen($allChars) - 1)];
        }

        return str_shuffle($code);
    }
    
    public function update(Request $request, $id)
    {
        $name = $request->input("name");
        $course = Course::where("id", $id)->update([
            "name" => $name,
        ]);

        return response()->json($course, 200);
    }

    public function delete($id)
    {
        $course = Course::where("id", $id)->delete();

        return response()->json($course, 200);
    }


    
}
