<?php

namespace App\Http\Controllers;

use App\Models\User_in_course;
use App\Models\Course;
use App\Models\Token;
use App\Models\User;
use Illuminate\Http\Request;

class UserInCourseController extends Controller
{
    public function indexByCourse(Request $request, $id)
    {
        // $users = User_in_course::with('user')->where("course_id", $id)->latest()->get()->pluck('user');
        $users = User_in_course::where("course_id", $id)->latest()->get()->map->user;

        return response()->json($users, 200);
    }

    public function indexByUser(Request $request)
    {
        $token = $request->bearerToken();
        $user_id = Token::where("token", $token)->first()->user_id;
        $courses = User_in_course::where("user_id", $user_id)->latest()->get()->map->course;
        return response()->json($courses, 200);
    }

    public function create(Request $request)
    {
        $token = $request->bearerToken();
        $user_id = Token::where("token", $token)->first()->user_id;
        $course = Course::where("access_code", $request->access_code)->first();
        if($course == null){
            return response()->json("Код не верный", 422);
        }
        if(User_in_course::where("user_id", $user_id)->where("course_id", $course->id)->first() != null){
            return response()->json("Пользователь существует", 422);
        }
        if(Course::where("user_id", $user_id)->first() != null){
            return response()->json("Нельзя добавить пользователя в свой же курс", 403);
        }
        User_in_course::create([
            "user_id" => $user_id,
            "course_id" => $course->id,
        ]);
        return response()->json("Пользователь добавлен", 200);
    }

    public function delete(Request $request, $id)
    {
        User_in_course::where("id", $id)->delete();
        return response()->json("Пользователь удален из курса", 200);
    }

}
